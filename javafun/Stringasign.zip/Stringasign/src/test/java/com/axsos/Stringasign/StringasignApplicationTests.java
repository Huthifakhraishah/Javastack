package com.axsos.Stringasign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StringasignApplicationTests {

	@Test
	void contextLoads() {
	}

}
