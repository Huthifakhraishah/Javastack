package com.axsos.CodingController;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodingControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
