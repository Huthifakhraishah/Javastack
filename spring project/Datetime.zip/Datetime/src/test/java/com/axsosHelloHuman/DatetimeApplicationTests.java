package com.axsosHelloHuman;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatetimeApplicationTests {

	@Test
	void contextLoads() {
	}

}
