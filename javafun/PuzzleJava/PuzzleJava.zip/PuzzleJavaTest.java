import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Arrays;

public class PuzzleJavaTest{
    public static void main(String[] args){
	PuzzleJava test = new PuzzleJava();
	int[] array = {3,5,1,2,7,9,8,13,25,32};
	System.out.println(test.Greater10(array));

	ArrayList<String> array= new ArrayList<String>();
	array.add("Nancy");
	array.add("Jinichi");
	array.add("Fujibayashi");
	array.add("Momochi");
	array.add("Ishikawa");
	System.out.println(test.Greater5C(array));	

	test.alphaVowel();

	System.out.println(Arrays.toString(test.randomArr()));

	System.out.println(test.randomArrSorted());
	System.out.println(test.generateWord());
    	System.out.println(test.arrayWords());
	}
}